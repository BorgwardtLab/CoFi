Coordination Finder 1.3
windows: cmd-> start CoordinationFinder.py
mac: python CoordinationFinder.py
File->Open to load data