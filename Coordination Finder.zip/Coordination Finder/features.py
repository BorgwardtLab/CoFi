# -*- coding: utf-8 -*-
"""
Created on Wed Apr 06 11:21:18 2016

@author: Sir Thomas
"""
import pandas as pd
import os.path as ospath
import numpy as np

from changepoint_methods import CP_loc
from statsmodels.stats.diagnostic import acorr_ljungbox
from lyapunov import max_lyapunov

import matplotlib.pyplot as plt


from scipy.stats import chi2,combine_pvalues


def Extract_Features(filename, Features=['length', 'fate', 'change', 'mchange', 'osc', 'inc', 'mean', 'sens', 'rate', 'ljungbox'], Columns=['cellNr', 'tree', 'stopReason', 'absoluteTime', ['intNanog','intKlf4']], inclomplete=[0,0]):
    
    data = pd.read_csv(filename)
    it = int(data.describe().ix[0,Columns[0]]) #how many data points
    DF_Columns = ['Start']
    for i in Features:
        if i == 'length' or i == 'fate':
            DF_Columns.append(str(i))
        else:
            for j in Columns[4]:
                DF_Columns.append(str(i)+str(j))
    
    points = pd.DataFrame(columns = DF_Columns) #Data frame for curves as single points
    temp1 = data.loc[0,Columns[0]]
    counter = 0
    points.set_value(counter,'Start',0)
    x = 0
    shift = 0
    if inclomplete[1] == 0:
        shift = -2 #exclude last two data points of every time series
    #features
    length = 0
    
    while x < it: #goes though file column by column
        temp2 = data.loc[x,Columns[0]]
        if ((temp2 != temp1) or (x == it-1)):
            if inclomplete[0] != 0 or int(temp2) != 1: #if the cell number changes, a new curve starts. Make sure that we exclude first cells because of incompleteness of the curves
                x = x + shift
                #location of previous cell starting point
                loc_counter = int(points.loc[counter, 'Start'])
                
                if x-loc_counter <= 0:
                    x = loc_counter+1
                length = int(x-loc_counter)
                    
                #get length of curve
                if 'length' in Features:
                    points.set_value(counter,'length', length)
                
                points.set_value(counter, 'fate', data.loc[loc_counter, Columns[2]])
                
                #get mean
                if 'mean' in Features:
                    mean = data[loc_counter:x].mean()
                    for j in Columns[4]:
                        points.set_value(counter,'mean'+str(j),mean.loc[str(j)])
                
                #endpoint
                b = data.loc[x-1, str(j)]
                if 'end' in Features:
                    for j in Columns[4]:
                        points.set_value(counter, 'end'+str(j), b)
                
                #Increase
                if 'inc' in Features:
                    for j in Columns[4]:
                        a = data.loc[loc_counter, str(j)]
                        points.set_value(counter, 'inc'+str(j), b-a)
                
                #rate
                if 'rate' in Features:
                    for j in Columns[4]:
                        a = data.loc[loc_counter, str(j)]
                        points.set_value(counter, 'rate'+str(j), (b-a)/length)
                
                #oscillations
                if 'osc' in Features:
                    osc = data[loc_counter:x].var()
                    for j in Columns[4]:
                        points.set_value(counter, 'osc'+str(j),osc.loc[str(j)])
                
                if (length > 2) and ('mchange' in Features):
                    for j in Columns[4]:
                        diff = []
                        i = 1
                        while i < length:
                            diff.append(data.loc[loc_counter+i:x-1, str(j)].sum()/(length-i+1) - data.loc[loc_counter:loc_counter+i-1, str(j)].sum()/i)    
                            i = i +1
                        diff = pd.Series(diff)
                        steepness = diff.max()
                        points.set_value(counter, 'mchange'+str(j), steepness)
                if (length <= 2) and ('mchange' in Features):
                        points.set_value(counter, 'mchange'+str(j), 0.)
                
                if 'change' in Features:
                    for j in Columns[4]:
                        hit  = 0
                        stop = 0
                        Ser = data.loc[loc_counter:x, str(j)]
                        Serd = [l-k for k, l in zip(Ser.tolist()[:-1], Ser.tolist()[1:])] 
                        #Is a change happening? If T-Test and CUSUM we assume it to happen
                        # Ask T-Test! p=0.05 usual statistical significance
                        if len(Serd) > 10:
                            stop,e,q,hit,b = CP_loc(Serd)
                        #stop = T_Test(0.05,Ser.values)
                        #CUSUM (k,h) = (1.5,1.61), (0.25,8), (0.5,8)
                        #hit = CUSUM([8,0.5],Ser.values)
                        
                        if hit != 0:
                            points.set_value(counter, 'change'+str(j), 1)
                        if hit == 0:
                            points.set_value(counter, 'change'+str(j), 0)
                        
                        if 'loc' in Features:
                            points.set_value(counter, 'loc'+str(j), float(hit)/length)
                            
                    
                #Do the Box-Piecre test for Autocorrelation (Compare to noise)
                #Hyndman http://robjhyndman.com/hyndsight/ljung-box-test/ recommends min(10, T/5) for non-seasonal time series
                #Stata uses min(n/2 − 2, 40) http://www.stata.com/manuals13/tswntestq.pdf
                #It is common to use a Ljung-Box test to check that the residuals from a time series model resemble white noise. if p <0.05 considered noise
                if 'ljungbox' in Features:
                    H = 4 #Gene transcription 10 minutes - 1 data point. Period = 2, Take 2*2 as suggested. 
                    for j in Columns[4]:
                        points.set_value(counter, 'ljungbox'+str(j), 0.)  #maybe make it less arbitrary
                        if length > 5:
                            Ser = list(data.loc[loc_counter:x, str(j)].values)
                            H = 7
                            H_ = 4
                            if len(Ser)-2 < H:
                                H = len(Ser)-2
                            if len(Ser)-2 < H_:
                                H_ = len(Ser)-2
                            Abs, p = acorr_ljungbox(Ser,lags=H)
                            binary = int(combine_pvalues(p[H_:])[1]-0.0001 < 0)
                            #print 'LJB', j, p[H-1]
                            #binary = int(p[H-1]-0.0001 < 0) #make sure null hypothesis is false uncomment for HH=4
                            points.set_value(counter, 'ljungbox'+str(j), binary)# p-value based on chi-square distribution - small p value means rejection of random distribution
                        else:
                            points.set_value(counter, 'ljungbox'+str(j), 0) #assume radnomness if nothing else
                
                #Compute the sensitivity to initial condistions (Lyapunov exponent as a measure of chaos)
                #Normalize this to a normally distributed sequence of smae length/mean/var???
                if 'sens' in Features:
                    for j in Columns[4]:
                        val = 1.
                        if length > 10:
                            Ser = data.loc[loc_counter:x, str(j)]
                            val = max_lyapunov(Ser.tolist())
                            #print 'LE', j, val
                        points.set_value(counter, 'sens'+str(j),val)
                
                
                x = x-shift
                points.set_value(counter+1,'Start',x)
                counter = counter +1
        
            if x != it-1:
                temp1 = temp2
        x = x+1

    points = points.dropna(axis=0,how='any')
    if inclomplete[0] == 0:
        points = points[points.fate != 0] #exclude last part of tree (incomplete curves)
        points = points[points.fate != 3]
    if 'fate' not in Features:
        points = points.drop('fate', 1)
    points.to_csv(ospath.join('points.csv'))


#Extract_Features("output_SerumLIF_141119_borgwardt.csv")
"""
EXPLANATION OF THE POINTS-FILE:

Start:
Pointer to Data where new curves start

length:
length of series

fate:
division, death, lost(3,0)

end...:
absolute intensity of Nanog/Klf4 at the end of cell life

mean...:
mean intensity over time

inc...:
Difference between start and end intensity

rate..:
Difference normalized to length of Series (production rate of TF)

osc...:
variance of the series

change...:
Student's t-test AND CUSUM for having a changepoint

mchange...:
max over all possible changepoints of difference between means second half compare to first half. 
mchange... > 0 => overall increase after point
-> related quadratically to osc

ljungbox...:
Ljung-Box test for no autocorrelation. Stores p-value based on chi-square distribution.
Ljung-Box test is reported to have better small sample properties compared to Box-Pierce
Informally, it is the similarity between observations as a function of the time lag between them. 
Do we need to include more datapoints than just one H= min(10, length/5)?

sens...:
lyapunov exponent. (chaos) A measure of how small differences evolve over time. devide by exp of same legth cumsum random sequence
"""