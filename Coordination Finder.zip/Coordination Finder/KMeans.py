# -*- coding: utf-8 -*-
"""
Created on Wed Apr 20 18:43:25 2016

@author: Sir Thomas
"""

import pandas as pd
import numpy as np
import os
import platform
import matplotlib.pyplot as plt
from scipy.cluster.vq import kmeans2, vq, whiten
from sklearn import metrics
import os.path as ospath
from statsmodels.sandbox.tools.tools_pca import pcasvd
from mpl_toolkits.mplot3d import Axes3D as ax3D
from scipy import stats
import random

from matplotlib.patches import FancyArrowPatch
from mpl_toolkits.mplot3d import proj3d

class Arrow3D(FancyArrowPatch):
    def __init__(self, xs, ys, zs, *args, **kwargs):
        FancyArrowPatch.__init__(self, (0,0), (0,0), *args, **kwargs)
        self._verts3d = xs, ys, zs

    def draw(self, renderer):
        xs3d, ys3d, zs3d = self._verts3d
        xs, ys, zs = proj3d.proj_transform(xs3d, ys3d, zs3d, renderer.M)
        self.set_positions((xs[0],ys[0]),(xs[1],ys[1]))
        FancyArrowPatch.draw(self, renderer)

def OptK(rescaled,Feat):
    k = 2
    silhouette = []
    
    while k < 7:
        np.random.seed(k*5)
        centroids = np.random.rand(k,len(Feat))
        centroids,labels = kmeans2(rescaled,centroids, minit='matrix')
        a = labels[0]
        if any(v != a for v in labels): #if there are two or more clusters, i.e. if any value is != 0
            silhouette.append(metrics.silhouette_score(rescaled, labels, metric='sqeuclidean'))
        else:
            silhouette.append(0)
        k = k+1
        
    silhouette = pd.Series(silhouette)
    k = silhouette.idxmax()+2 #choose k with highest silhouette score
    return int(k)

def Clean_Data(data,Feat,Force):
    #Clean up data
    data = data.loc[:,Feat].dropna(axis=1, how='any') #Remove unusable rows (and unused colums?)
    data = data[(np.abs(stats.zscore(data)) < 3).all(axis=1)] #Exclude outliers if <5 does not work!!!
    p_df = data.values.astype(float) #convert to List
    rescaled = whiten(p_df) #norm to var=1, need to include subtraction of mean!!!
    
    """
    #WHAT FOLLOWS IS TO SUBTRACT THE MEAN - MAYBE WE CAN INCLUDE IT TO whiten??
    #SLOWS DOWN STABILITY ANALYSIS
    """
    analysis = pd.DataFrame(rescaled)
    i = 0
    while i < len(analysis.columns.values):
        meani = analysis.describe().iloc[1,i]
        for j,rows in analysis.iterrows():
            rescaled[j,i] = rescaled[j,i] - meani
        i = i + 1
    #print pd.DataFrame(rescaled).describe()
    
    #Choose k
    if Force == 0:
        k = OptK(rescaled,Feat)
    if Force != 0:
        k = Force #User Forces amount of clusters
    
    return rescaled, k


def Show_KMeans(Space, Force=0, filename=0, Feat=0, Bias =0, Tree = 1, Columns=['cellNr', 'tree', 'stopReason', 'absoluteTime', ['intNanog','intKlf4']]):
    data=pd.read_csv(ospath.join("points.csv"), index_col=1)
    if Feat == 0:
        Feat = list(data)[1:]
    if Bias == 'nanog':
        i = 0
        while i < len(Feat):
            if 'Klf4' in Feat[i]:
                Feat.pop(i)
            else:
                i = i+1
    plt.ion()  
    rescaled, k = Clean_Data(data, Feat, Force)
    #RUN KMEANS
    np.random.seed(k*5)
    centroids = np.random.rand(k,len(Feat))
    centroids,labels = kmeans2(rescaled,centroids, minit='matrix')
    idx,_ = vq(rescaled,centroids)
    
    colors = ['orange', 'blue', 'azure', 'lightcyan', 'grey', 'lightblue', 'yellow']
    ax = ax3D(plt.gcf())
        
    if Force == 0:
        ax.text2D(0.05, 0.95, 'Maximal mean silhouette coefficient ' + str(round(metrics.silhouette_score(rescaled, labels, metric='sqeuclidean'),3))+' using k=' + str(int(k)) + ' clusters.', transform=ax.transAxes, fontsize=14)
    if Force != 0:
        ax.text2D(0.05, 0.95, 'Mean silhouette coefficient ' + str(round(metrics.silhouette_score(rescaled, labels, metric='sqeuclidean'),3))+' using k=' + str(int(k)) + ' clusters.', transform=ax.transAxes)
    
    if Space == 'PCA' and len(Feat) > 2:
        #RUN PCA
        pca = pcasvd(rescaled, keepdim=0, demean=False)
        
        xpc, ypc, zpc = (0, 1, 2)
        xreduced, factors, evals, evecs = pca
        singvals = np.sqrt(evals)
        scale = 1
        
        # data
        xs = factors[:, xpc] * singvals[xpc]**(1. - scale)
        ys = factors[:, ypc] * singvals[ypc]**(1. - scale)
        zs = factors[:, zpc] * singvals[zpc]**(1. - scale)
        
        cluster=0
        while cluster < k:
            ax.scatter(xs[idx==cluster], ys[idx==cluster], zs[idx==cluster], c=colors[cluster]) 
            cluster = cluster+1
        
        tvars = np.dot(np.eye(factors.shape[0], factors.shape[1]),evecs) * singvals**scale
    
        i = 0
        while i < len(Feat): # enumerate(xreduced.columns.values):
            x, y, z = tvars[i][xpc], tvars[i][ypc], tvars[i][zpc]
            a = Arrow3D([0,x*4], [0,y*4], [0,z*4], mutation_scale=20, lw=1, arrowstyle="-|>", color="k")
            ax.add_artist(a)
            ax.text(x* 4.4, y * 4.4, z* 4.4, Feat[i], color='k', fontsize=14)
            i = i+1
    
        ax.set_xlabel('PC1', fontsize=16)
        ax.set_ylabel('PC2', fontsize=16)
        ax.set_ylabel('PC3', fontsize=16)
    
    data = data.loc[:,Feat].dropna(axis=0, how='any')
    data = data[(np.abs(stats.zscore(data)) < 3).all(axis=1)] #Exclude outliers
    p_df = data.values.astype(float)
    if Space != 'PCA' and len(Feat) > 3:
        #Determine the three Features with most variation and use them as the axes
        var = pd.DataFrame(p_df).var(axis=0).order(ascending=False).index.tolist()
        x=0
        while x < k:
            ax.scatter(p_df[idx==x,var[0]], p_df[idx==x,var[1]], p_df[idx==x,var[2]], c=colors[x]) 
            x = x+1

        ax.set_xlabel(Feat[var[0]])
        ax.set_ylabel(Feat[var[1]])
        ax.set_zlabel(Feat[var[2]])
      
    if platform.system() == 'Windows':    
        plt.show(block=True)
    if platform.system() == 'Linux':
        plt.show(block=False) #not showing anything
    
    if filename != 0:
        data['Cluster'] = labels
        #Feat = 'Cluster'
        #from coordination import Coordination_Plots
        #Coordination_Plots(data,[Feat],filename,"Coordination of clusters.png")
    
        #save total result to .csv
        if Tree == 1:
            curves=pd.read_csv(filename)
            from save_tree import save_tree
            save_tree(data,curves,'tree.csv',Columns)
    return k
    